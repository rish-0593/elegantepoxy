<?php

    // Set the SMTP server to send through
    $host       = 'sandbox.smtp.mailtrap.io';

    // SMTP username
    $username   = '497db380d0dd65';

    // SMTP password
    $password   = "051f2b16c1d5f0";

    // Enable implicit TLS encryption
    $SMTPSecure = 'SSL';

    // TCP port to connect to
    $port       = 465;

    // Mail Subject
    $subject    = 'Elegant Epoxy: Enquiry';

    // Mail Address
    $mails = [
        'rishabh.kumar.ads@gmail.com' => 'Rishabh',
    ];