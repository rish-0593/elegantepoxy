## Composer

```bash
composer install
```

## For Environment Variable Create

```bash
cp env.php.example env.php
```

## License

This is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
